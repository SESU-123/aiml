import streamlit as st
import cohere

# Initialize Cohere client with your API key
co = cohere.Client("d825LVpOBgb73nEe0p1cYguv44LveE12ZctPl4CN")

# Streamlit UI
st.set_page_config(page_title="Text Summarizer with Cohere")
st.title("📝 NLP Text Summarizer")
st.write("Enter a long piece of text and get a short summary using Cohere's language model.")

# Text input
text = st.text_area("Enter the text to summarize:", height=200)

# Summarize button
if st.button("Summarize"):
    if text.strip() == "":
        st.warning("Please enter some text to summarize.")
    else:
        # Prompt to instruct summarization
        prompt = f"Summarize the following text in a concise paragraph:\n\n{text}"
        
        # Call Cohere API
        response = co.generate(
            model="command",
            prompt=prompt,
            max_tokens=100,
            temperature=0.5
        )

        # Display summary
        summary = response.generations[0].text.strip()
        st.subheader("Summary:")
        st.success(summary)
